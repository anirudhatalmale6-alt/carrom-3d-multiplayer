﻿namespace AssetStoreTools.Validator.TestDefinitions
{
    public class ValidationTestConfig
    {
        public string[] ValidationPaths;
    }
}