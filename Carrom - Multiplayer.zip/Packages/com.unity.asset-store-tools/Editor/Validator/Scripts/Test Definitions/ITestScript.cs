﻿using AssetStoreTools.Validator.Data;

namespace AssetStoreTools.Validator.TestDefinitions
{
    internal interface ITestScript
    {
        TestResult Run(ValidationTestConfig config);
    }
}